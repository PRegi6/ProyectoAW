COSAS POR HACER DE AW:
Un usuario puede ver su perfil y poder cambiar su plan de pago
Reproductor ocultarlo cuando no se escuche una cambion --hecho
Hacer crear playlist de forma bonita
Añadir canciones
y las dos funcionalidades finales

Personas de BD
Administradores:
ADMIN@gmail.com	ADMINPASS
ADMIN@gmail.com	ADMINPASS2
USUARIOS:
franzroq@ucm.es kezo2002 Artista
pabloregi@ucm.es	contraseña Premium
david@ucm.es	polvoron Normal

Funcionalidades: 
1- Gestión de Administrador
2- Gestión de recomendación de canciones
3- Gestión de contenido (incluye la gestión de artistas y canciones)
4- Gestión de anuncios (incluye la gestión de anuncios por roles)
5- Gestión de playlist (incluye la crear, modificar, borrar y compartir una playlist. También incluye el swipe para canciones)
6- Gestión de suscripción (incluye la gestión del pago por suscripción y carrito) 

Login - Jorge y Marc
Registro - Alonso
Planes Funcionalidad de suscripcion - Victor
Base de datos modelo - Regi y Rodri Q
La pagina principal - Regi y Rodri Q
Reproductor - Regi y Rodri Q
Panel Admin Funcionalidad admin - Jorge
Gestión de contenido (incluye la gestión de artistas y canciones) - Marc
Playlist Funcionalidad de las playlist - Alonso y Victor

Contraseña: eP4aer6oethahre (para todo)

phpMyAdmin: https://phpmyadmin.containers.fdi.ucm.es
  - Usuario: root
  - servidor: vm09.db.swarm.test

Guacamole: https://guacamole.containers.fdi.ucm.es
Guacamole:
  - Usuario: vm09

Producción: https://vm09.containers.fdi.ucm.es -> /var/www/produccion

Beta: https://vm09-beta.containers.fdi.ucm.es -> /var/www/pruebas

VPN UCM: https://www.ucm.es/faq/vpn/vpn-estudiantes
