<footer class="footer">
        <a href="contacto.php"><button class="botonContacto">CONTACTO</button></a>
        <div class="redesSociales">
                <a href="https://twitter.com/BeatHouseAW" target="_blank"><img src="<?= RUTA_IMGS ?>/logoTwitter.png" alt="twitter" class="logoTw"></a>
                <a href="https://www.instagram.com/beatthouse" target="_blank"><img src="<?= RUTA_IMGS ?>/logoInsta.png" alt="instagram" class="logoInsta"></a>
        </div>
</footer>