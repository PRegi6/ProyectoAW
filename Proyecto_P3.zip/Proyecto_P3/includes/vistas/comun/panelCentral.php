<div class="contenidoPrincipal">
    <nav>
        <h2>Panel Principal</h2>
    </nav>
</div>