<?php
    require_once __DIR__."/includes/config.php";
    $tituloPagina = "Tendencias";
    $contenidoPrincipal = "Aqui hirá lo que viene a ser las tendencias";

    require RAIZ_APP."/vistas/plantillas/plantilla.php";