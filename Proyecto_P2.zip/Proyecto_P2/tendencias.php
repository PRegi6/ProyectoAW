<?php
    require_once __DIR__."/includes/config.php";
    
    $tituloPagina = "Tendencias";
    $contenidoPrincipal = "Contendra las tendencias";

    require RAIZ_APP."/vistas/plantillas/plantilla.php";