<?php
    require_once __DIR__."/includes/config.php";
    
    $tituloPagina = "Playlist";
    $contenidoPrincipal = "Contendra las Playlist";

    require RAIZ_APP."/vistas/plantillas/plantilla.php";