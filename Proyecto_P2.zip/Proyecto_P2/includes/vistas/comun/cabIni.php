<header>
    <section class="cabInicio">
        <a href="index.php"><img class="volver" src='<?=RUTA_IMGS?>/cerrar.svg'></a>
    </section>
</header>