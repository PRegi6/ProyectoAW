<footer class="footer">
        <h1>Contacto</h1>
        <img src="<?= RUTA_IMGS ?>/logoTwitter.png" alt="twitter" class="logoTw">
        <img src="<?= RUTA_IMGS ?>/logoInsta.png" alt="instagram" class="logoInsta">
</footer>